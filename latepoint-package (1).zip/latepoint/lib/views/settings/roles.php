<div class="os-section-header"><h3><?php _e('User Roles', 'latepoint'); ?></h3></div>
<a href="<?php echo OsRouterHelper::build_link(['addons', 'index']); ?>" class="os-add-box">
	<div class="add-box-graphic-w">
		<div class="add-box-plus"><i class="latepoint-icon latepoint-icon-plus4"></i></div>
	</div>
	<div class="add-box-label"><?php _e('Install Roles Manager Add-on', 'latepoint'); ?></div>
</a>