Hi {customer_full_name},
<br>
<br>
The status of your {service_name} with <strong>{agent_full_name}</strong> was changed from <strong>{booking_old_status}</strong> to <strong>{booking_status}</strong>.
<br>
<br>
<h4>Appointment Details:</h4>
<ul>
	<li>
		<span>Agent:</span> <strong>{agent_full_name}</strong>
	</li>
	<li>
		<span>Service:</span> <strong>{service_name}</strong>
	</li>
	<li>
		<span>Date, Time:</span> <strong>{start_date}, {start_time} - {end_time}</strong>
	</li>
</ul>
<div style="margin-top: 25px;">
	<a href="{{manage_booking_url_customer}}" style="display: block; text-decoration: none; padding: 10px; border-radius: 6px; text-align: center; font-size: 18px; color: #fff; background-color: #2652E4; font-weight: 700;">Manage This Appointment</a>
</div>