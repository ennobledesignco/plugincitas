<div class="step-verify-w latepoint-step-content" data-step-name="verify">
  <div class="latepoint-step-content-text-left">
    <div><?php _e('Double check your booking information, you can go back to edit it or click submit button to confirm your booking.', 'latepoint'); ?></div>
  </div>
  <div class="confirmation-info-w">
	  <?php include('partials/_booking_summary.php'); ?>
  </div>
</div>